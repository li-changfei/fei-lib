import pygame

from enumClass import Direction


class Tank:
    def __init__(self, ai_settings, screen):
        # 初期化
        self.screen = screen
        self.ai_settings = ai_settings
        # 加载坦克图像并获取其外接矩形
        self.moving_image = pygame.image.load('images/tank_y.jpg')
        self.image = pygame.image.load('images/tank_y.jpg')
        self.rect = self.moving_image.get_rect()
        self.screen_rect = screen.get_rect()
        # 将每艘新坦克放在屏幕底部中央
        # self.rect.centerx = self.screen_rect.centerx
        self.rect.x = 180
        self.rect.bottom = self.screen_rect.bottom
        # 移动标志
        self.moving_right = False
        self.moving_left = False
        self.moving_up = False
        self.moving_down = False
        # 在坦克的属性center中存储小数值
        self.center = float(self.rect.centerx)
        self.bottom = float(self.rect.bottom)
        # 坦克运行的方向
        self.direction = Direction.up
        # 坦克唯一标识
        self.bullet_count = 0

    def blitme(self):
        """在指定位置绘制飞船"""
        self.screen.blit(self.moving_image, self.rect)

    def upadte(self):
        """持续运动"""
        if self.moving_right and self.rect.right < self.screen_rect.right:
            self.center += self.ai_settings.tank_speed_factor
        if self.moving_left and self.rect.left > 0:
            self.center -= self.ai_settings.tank_speed_factor
        if self.moving_up and self.rect.top > 0:
            self.bottom -= self.ai_settings.tank_speed_factor
        if self.moving_down and self.rect.bottom < self.screen_rect.bottom:
            self.bottom += self.ai_settings.tank_speed_factor

        # 根据self.center更新rect对象
        self.rect.centerx = self.center
        self.rect.bottom = self.bottom

    def transform(self, direction):
        if direction == Direction.right:
            if self.direction != Direction.right:
                self.direction = Direction.right
                self.moving_image = pygame.transform.rotate(self.image, 270)
        elif direction == Direction.left:
            if self.direction != Direction.left:
                self.direction = Direction.left
                self.moving_image = pygame.transform.rotate(self.image, 90)
        elif direction == Direction.up:
            if self.direction != Direction.up:
                self.direction = Direction.up
                self.moving_image = pygame.transform.rotate(self.image, 0)
        elif direction == Direction.down:
            if self.direction != Direction.down:
                self.direction = Direction.down
                self.moving_image = pygame.transform.rotate(self.image, 180)

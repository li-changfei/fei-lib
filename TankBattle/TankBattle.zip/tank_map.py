global tank_map
tank_map = {}


def set_map(key, value):
    tank_map[key] = value


def get_map(key):
    return tank_map[key]
